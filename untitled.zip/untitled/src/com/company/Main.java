package com.company;
import java.io.*;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Random;
import java.util.Scanner;
import java.lang.Integer;

public class Main {
    public static void main(String[] args) {
        byte[] byteArr = readBytesFromFile("send.txt");
        System.out.println(new String(byteArr));
        byte[] hamArr = hamItUp(byteArr);
        System.out.println(new String(hamArr));
        writeToFileBytes(hamArr, "encoded.txt");

        send("encoded.txt", "received.txt");

        byte[] recArr = readBytesFromFile("received.txt");
        byte[] finArr = hamItDown(recArr);
        System.out.println(new String(finArr));
        writeToFileBytes(finArr, "decoded.txt");


//        String str = readFromFile();
//        System.out.println(str);

//        String hexStr = toHex(str);
//        System.out.println(hexStr);

//        String binStr = toBinary(hexStr);
//        System.out.println(binStr);


//        byte[] byteArr = readBytesFromFile("send.txt");

//        byte[] encodedBytes = encode(byteArr);
//        writeToFileBytes(encodedBytes, "encoded.txt");

//        send("encoded.txt","received.txt");

//        decode("received.txt", "decoded.txt");

//        byte[] binErrArr = genBinErr(byteArr);
//        writeToFileBytes(binErrArr);
//
//        System.out.println();
//        String str = readFromFile();
//        System.out.println(str);

//        String hexStr = toHex(str);
//        System.out.println(hexStr);

//        String binStr = toBinary(hexStr);
//        System.out.println(binStr);

//        String binErrStr = generateBinaryErrors(binStr);
//        System.out.println(binErrStr);

//        String hexErrStr = toHexFromBinary(binErrStr);
//        System.out.println(hexErrStr);

//        String errStr = toStringFromHex(hexErrStr);
//        System.out.println(errStr);

//        writeToFile(errStr);
//        writeToFileHex(hexErrStr);

//        String tripleStr = tripleChar(str);
//        System.out.println(tripleStr);
//
//        String encodedString = generateErrors(tripleStr);
//        System.out.println(encodedString);
//
//        String decodedString = decodeString(encodedString);
//        System.out.println(decodedString);

    }

//    private static String decodeString(String str) {
//        String cleanStr = "";
//
//        for (int i = 0; i < str.length(); i +=3) {
//            char x = ' ';
//            String workStr = str.substring(i, str.length());
//            if (workStr.charAt(0) == workStr.charAt(1)) {
//                x = workStr.charAt(0);
//            }
//            if (workStr.charAt(0) == workStr.charAt(2))  {
//                x = workStr.charAt(0);
//            }
//            if (workStr.charAt(1) == workStr.charAt(2))  {
//                x = workStr.charAt(1);
//            }
//            cleanStr += Character.toString(x);
//        }
//        return cleanStr;
//    }
//    public static String tripleChar(String str){
//        String outputStr = "";
//        for (int i = 0; i < str.length(); i++) {
//            outputStr += str.charAt(i) + "" + str.charAt(i) + "" + str.charAt(i);
//        }
//        return outputStr;
//    }
//    public static String generateErrors(String str){
//        Random rnd = new Random();
//        for (int i = 0; i < str.length(); i +=3) {
//            String rSub = "";
//            String oStr = "";
//            int r = 0;
//            int strLength = str.length();
//            if (i+3 > strLength) {
//                oStr = str.substring(i, strLength);
//                rSub = str.substring(i, strLength);
//                r = (int)(Math.random() * rSub.length()) ;
//            } else {
//                oStr = str.substring(i, i+3);
//                rSub = str.substring(i, i+3);
//                r = (int)(Math.random() * 3) ;
//            }
////            System.out.println(i+" "+(i+3)+" "+rSub);
////            System.out.println(oStr+" | "+rSub);
////            System.out.println("\tr: "+r);
//
//            String c = Character.toString(getRandomChar());
//            rSub = replaceChar(rSub, r, c);
////            System.out.println("\t"+x+" "+c+" "+rSub);
////            System.out.println("\t"+rSub);
//            str = str.substring(0, i) + rSub + str.substring(i+3, strLength);
////            System.out.println(oStr+" | "+rSub);
//        }
////        System.out.println(str);
////        System.out.println("length: "+str.length());
//        return str;
//    }
//    public static char getRandomChar() {
//        int rChar = (int)(Math.random() * 126);
//        if (rChar < 32) {
//            rChar *= 2;
//        }
//        return (char) rChar;
//
//    }
//    public static String replaceChar(String str, int index, String rChar) {
//        str = str.substring(0, index)
//                + rChar
//                + str.substring(index + 1);
//        return str;
//    }
//    public static String toHex(String str){
//        String hexString = "";
//        char[] charArr = str.toCharArray();
//        for (char c : charArr) {
//            int cInt = c;
//            String hexVal = Integer.toHexString(cInt);
//            hexString += hexVal+" ";
//        }
//        return hexString.trim();
//    }
//    public static String toBinary(String str) {
//        String binaryString = "";
//        String[] strArr = str.split(" ");
//        for (String st : strArr) {
//            String binaryStr = (String) Long.toBinaryString(Long.parseLong(st, 16));
//            while (binaryStr.length() < 8) {
//                binaryStr = "0" + binaryStr;
//            }
//            binaryString += binaryStr + " ";
//        }
//        return binaryString.trim();
//    }
//    public static String generateBinaryErrors(String str){
//        String[] strArr = str.split(" ");
//        for (int i = 0; i < strArr.length; i++) {
//            int rChar = (int)(Math.random() * 6);
//            String selectedChar = strArr[i].substring(rChar, rChar+1);
//            String ch = "0";
//            if (selectedChar.equals("0")) {
////                System.out.println("change ch");
//                ch = "1";
//            }
////            System.out.println("string: "+strArr[i]+"\nrChar: "+ rChar +"\nselectedChar: "+ selectedChar + "\nch: "+ ch);
//            String xVal = strArr[i].substring(0, rChar) + ch + strArr[i].substring(rChar + 1);
//            strArr[i] = xVal;
////            System.out.println("xVal: " + xVal);
////            System.out.println("-----------------");
//        }
////        System.out.println();
//        String rtnStr = Arrays.toString(strArr);
//        rtnStr = rtnStr.replaceAll("(\\[|\\]|,)", "");
//
//        return rtnStr.trim();
//    }
//    public static String toHexFromBinary(String str){
//        String[] strArr = str.split(" ");
//        String rtnStr = "";
//        for (String st : strArr) {
//            rtnStr += Long.toHexString(Long.parseLong(st,2)) + " ";
//        }
//        return rtnStr.trim().toUpperCase();
//    }
//    public static String toStringFromHex(String str){
//        String[] strArr = str.split(" ");
//        String rtnStr = "";
//        for (String st : strArr) {
//            if (st.length() == 2) {
//                rtnStr += (char)(Integer.parseInt(st, 16));
//            } else {
//                rtnStr += (char)(Integer.parseInt("0"+st, 16));
//            }
//        }
//        return rtnStr.trim();
//    }
//    public static String readFromFile(){
//        String str = "";
//        File myObj = new File("send.txt");
//        try {
//            Scanner s = new Scanner(myObj);
//            while (s.hasNextLine()) {
//                str = s.nextLine();
////                System.out.println("212: "+str);
//            }
//            s.close();
//        } catch (FileNotFoundException e) {
//            System.out.println("An error occurred.");
//            e.printStackTrace();
//        }
//        return str.trim();
//    }
//    public static void writeToFile(String str){
//        byte[] bytesArray = new byte[str.length()];
//        for (int i = 0; i < str.length(); i++) {
//            int x = str.charAt(i);
//            bytesArray[i] = (byte) x;
//        }
//        try {
//            FileOutputStream fw = new FileOutputStream("received.txt");
//            fw.write(bytesArray);
//            fw.close();
//        } catch (IOException e) {
//            System.out.println("An error occurred.");
//            e.printStackTrace();
//        }
//    }
//    public static byte[] encode(byte[] byteArr){
//        String encodedByteStr = "";
//        String tempByte = "";
//
//        for (int i = 0; i < byteArr.length; i++) {
//
//            for (int j=0; j<8; j++) {
//                int x = (int)(byteArr[i] >> (8-(j+1)) & 0x0001);
//                tempByte += x+""+x;;
//                if (i == (byteArr.length - 1) && j == 7) {
//                    while(tempByte.length() <= 4){
//                        tempByte += "00";
//                    }
//                }
//                if (tempByte.length() == 6) {
//                    int y = Integer.parseInt(tempByte.substring(0, 1)) ^ (Integer.parseInt(tempByte.substring(2, 3)) ^ (Integer.parseInt(tempByte.substring(4, 5))));
//                    tempByte += y+""+y;
//                    encodedByteStr += tempByte+" ";
//                    tempByte = "";
//                }
//            }
//        }
//        String[] strArr = encodedByteStr.split(" ");
//
//        byte[] array = new byte[strArr.length];
//        int pos = 0;
//        for (String st : strArr) {
//            array[pos] = (byte)Integer.parseInt(st, 2);
//            pos++;
//        }
//        return array;
//    }

    public static byte[] readBytesFromFile(String fileName){
        File myObj = new File(fileName);
        int arrLen = (int) myObj.length();
        byte[] content = new byte[arrLen];
        try (FileInputStream input = new FileInputStream(myObj)) {
            content = input.readAllBytes();
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: Input file not found:");
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("ERROR: Input file (see below) - some other exception occurred!");
            e.printStackTrace();
        }
        return content;
    }
    public static byte[] genBinErr(byte[] binArr){
        for (int i = 0; i < binArr.length; i++) {
            binArr[i] = flipOneRandomBitInByte(binArr[i]);
        }
        return binArr;
    }
    static byte flipOneRandomBitInByte(byte b) {
        Random rnd = new Random();
        return flipNthBitInByte(b, rnd.nextInt(8));
    }
    static byte flipNthBitInByte(byte b, int n) {
        return (byte) (b = (byte) (b ^ (1 << n)));
    }
    public static void writeToFileBytes(byte[] byteArr, String fileName){
        try {
            FileOutputStream fw = new FileOutputStream(fileName);
            fw.write(byteArr);
            fw.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    public static void send(String encodedFile, String receivedFile){
        byte[] byteArr = readBytesFromFile(encodedFile);
        byte[] errArr = genBinErr(byteArr);
        writeToFileBytes(errArr, receivedFile);
    }
    public static void decode(String receivedFile, String decodedFile) {
        byte[] byteArr = readBytesFromFile(receivedFile);
        String workingStr = "";

        for (int i = 0; i < byteArr.length; i++) {
//            System.out.println(String.format("%8s", Integer.toBinaryString(byteArr[i] & 0xFF)).replace(' ', '0'));
            int[] aArr = new int[4];
            int[] bArr = new int[4];
            int k = 0;

            for (int j=0; j<8; j+=2) {
                int a = (int) (byteArr[i] >> (8 - (j + 1))) & 0x0001;
                int b = (int) (byteArr[i] >> (8 - (j + 2))) & 0x0001;
                aArr[k] = a;
                bArr[k] = b;
                k++;
            }

            boolean aGood = false;
            boolean bGood = false;

            int x = aArr[0] ^ aArr[1] ^ aArr[2];
            int y = bArr[0] ^ bArr[1] ^ bArr[2];
//            System.out.println("\tx: "+x+" | y: "+y);

            aGood = aArr[3] == x;
            bGood = bArr[3] == y;
//            System.out.println("\t"+aGood +"|"+ bGood);
            String tempStr = "";
            if (aGood && !bGood) {
//                System.out.println("\taArr: "+Arrays.toString(aArr));
                tempStr = Arrays.toString(aArr).replaceAll("\\[|\\]|,|\\s", "");
            }
            if (!aGood && bGood) {
//                System.out.println("\tbArr: "+Arrays.toString(bArr));
                tempStr = Arrays.toString(bArr).replaceAll("\\[|\\]|,|\\s", "");
            }
            tempStr = tempStr.substring(0, 3);
            workingStr += tempStr;

        }
        workingStr = workingStr.replaceAll("(.{" + 8 + "})", "$1 ").trim();
//        System.out.println("===========================");
//        System.out.println(workingStr);
        System.out.println(workingStr.length()%9);
        int extra = workingStr.length() % 9;
        if (extra < 8) {
            workingStr = workingStr.substring(0, workingStr.length() - extra);
        }
        String[] strArr = workingStr.trim().split(" ");

        System.out.println(strArr.length+": "+Arrays.toString(strArr));

        byte[] byteArray = new byte[strArr.length];
        for (int i = 0; i < strArr.length; i++) {
            byteArray[i] = Byte.parseByte(strArr[i], 2);
        }
        writeToFileBytes(byteArray, "decoded.txt");
    }

    public static byte[] hamItUp(byte[] byteArr){
        String encodedByteStr = "";
        for (int i = 0; i < byteArr.length; i++) {
            String tempByte1 = "";
            int p1a;
            int p2a;
            int d3a = (int)(byteArr[i] >> (8-(1)) & 0x0001);
            int p4a;
            int d5a = (int)(byteArr[i] >> (8-(2)) & 0x0001);
            int d6a = (int)(byteArr[i] >> (8-(3)) & 0x0001);
            int d7a = (int)(byteArr[i] >> (8-(4)) & 0x0001);
//            System.out.print("." + "." + d3a + "." + d5a + d6a + d7a + ".");

            p1a = d3a ^ d5a ^ d7a;
            p2a = d3a ^ d6a ^ d7a;
            p4a = d5a ^ d6a ^ d7a;
            tempByte1 = "" + p1a + p2a + d3a + p4a + d5a + d6a + d7a + 0;
//            System.out.print("\n"+tempByte1);

// =========================================================

            String tempByte2 = "";
            int p1b;
            int p2b;
            int d3b = (int)(byteArr[i] >> (8-(5)) & 0x0001);
            int p4b;
            int d5b = (int)(byteArr[i] >> (8-(6)) & 0x0001);
            int d6b = (int)(byteArr[i] >> (8-(7)) & 0x0001);
            int d7b = (int)(byteArr[i] >> (8-(8)) & 0x0001);

//            System.out.print("\n"+"." + "." + d3b + "." + d5b + d6b + d7b + ".");

            p1b = d3b ^ d5b ^ d7b;
            p2b = d3b ^ d6b ^ d7b;
            p4b = d5b ^ d6b ^ d7b;
            tempByte2 = "" + p1b + p2b + d3b + p4b + d5b + d6b + d7b + 0;
//            System.out.println("\n"+tempByte2);

            encodedByteStr += tempByte1 + " " + tempByte2 + " ";
//            System.out.println(encodedByteStr+"\n");
        }
        String[] strArr = encodedByteStr.trim().split(" ");
        byte[] rtnArray = new byte[strArr.length];
        int pos = 0;
        for (String st : strArr) {
            rtnArray[pos] = (byte)Integer.parseInt(st, 2);
            pos++;
        }
        return rtnArray;
    }
    public static byte[] hamItDown(byte[] byteArr) {
        String decStr = "";
        for (int i = 0; i < byteArr.length; i++) {
            String tempByte1 = "";
            int p1a = (int) (byteArr[i] >> (7) & 0x0001);
            int p2a = (int) (byteArr[i] >> (6) & 0x0001);
            int d3a = (int) (byteArr[i] >> (5) & 0x0001);
            int p4a = (int) (byteArr[i] >> (4) & 0x0001);
            int d5a = (int) (byteArr[i] >> (3) & 0x0001);
            int d6a = (int) (byteArr[i] >> (2) & 0x0001);
            int d7a = (int) (byteArr[i] >> (1) & 0x0001);

            int bal1 = d3a ^ d5a ^ d7a;
            int bal2 = d3a ^ d6a ^ d7a;
            int bal4 = d5a ^ d6a ^ d7a;

            int chk1 = p1a ^ bal1;
            int chk2 = p2a ^ bal2;
            int chk4 = p4a ^ bal4;

            if (chk1 != 0 && chk2 != 0 && chk4 == 0) {
                if (d3a == 0) {
                    d3a = 1;
                } else {
                    d3a = 0;
                }
            }
            if (chk1 != 0 && chk2 == 0 && chk4 != 0) {
                if (d5a == 0) {
                    d5a = 1;
                } else {
                    d5a = 0;
                }
            }

            if (chk1 == 0 && chk2 != 0 && chk4 != 0) {
                if (d6a == 0) {
                    d6a = 1;
                } else {
                    d6a = 0;
                }
            }


            if (chk1 != 0 && chk2 != 0 && chk4 != 0) {
                if (d7a == 0) {
                    d7a = 1;
                } else {
                    d7a = 0;
                }
            }

            tempByte1 = "" + d3a + d5a + d6a + d7a;
            decStr += tempByte1;
            if (i % 2 != 0) {
                decStr += " ";
            }

        }

        String[] strArr = decStr.trim().split(" ");
        byte[] rtnArray = new byte[strArr.length];
        int pos = 0;
        for (String st : strArr) {
            rtnArray[pos] = (byte)Integer.parseInt(st, 2);
            pos++;
        }
        return rtnArray;
    }
}
