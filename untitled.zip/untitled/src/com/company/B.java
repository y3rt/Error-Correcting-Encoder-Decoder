package com.company;

class B {
    B b = new B(); // (1)

    C c1 = new C();  // (2)

    C c2 = new com.company.C(); // (3)

//    mypackage.C c3 = new com.company.C(); // (4)
//
//    com.A a = new com.A(); // (5)

    A a1 = new A(); // (6)
}
